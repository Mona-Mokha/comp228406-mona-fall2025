package ex3;

public interface MortgageConstants {

    int SHORT_TERM  = 1;
    int MEDIUM_TERM = 3;
    int LONG_TERM = 5;
    String BANK_NAME = "CityToronto bank ";
    double Max_Amount = 300000.0;
}
