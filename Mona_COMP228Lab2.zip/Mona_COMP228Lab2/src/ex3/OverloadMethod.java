package ex3;

public class OverloadMethod {

    public static int adding(int a, int b) {
        return a + b;
    }

    public static double adding(double a, double b, double c) {
        return a + b + c;
    }

    public static String adding(String a, String b) {
        return a + b;

    }
}
