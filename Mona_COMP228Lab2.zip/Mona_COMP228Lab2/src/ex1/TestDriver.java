package ex1;

public class TestDriver {

    public static void main(String[] args) {
        Test test = new Test();
        test.inputAnswer();
    }
}
